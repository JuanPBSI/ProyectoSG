# Proyecto: Herramienta Para monitoreo de bitácoras relacionadas con servicios web
	Paln de Becarios en Seguridad Informática Decima Generacón
	Elaboró: José Juan Armenta Segura
			 Diego Alfonso Serrano Gillén
# Instalación rápida
	1) Copiar o clonar éste repositorio
	2) Ejecutar con permisos de administrador (root) el script installServer.sh
		Se creará o se usara el usario ingresado
	3) Cambiarse a la cuenta de usuario ingresada (su - [usuario])
	4) Ubicarse en el directorio /opt/Proyecto/ (cd /opt/Proyecto/)
	5) Ejecutar el script installSSH.sh (~$ sh installSSH.sh) y seguir las instrucciones
		Introducir usarios e ip de los servidores externos
		IMPORTANTE: el usuario ingresado debe tener permisos para leer los logs del servidor web y base de datos
					así mismo debe terner permisos para escribir en el direcrotio /tmp/
	6) Importante estar ubicado en el directorio /opt/Proyecto/ (cd /opt/Proyecto/)
	7) Ejecutar el Script Proyecto.py (~$ python Proyecto.py)

